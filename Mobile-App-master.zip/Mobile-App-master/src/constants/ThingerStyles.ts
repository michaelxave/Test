export const PADDING = 15;
export const SEPARATOR_PADDING = 7;
export const BORDER_RADIUS = 5;
export const MARGIN = 10;
export const FONT_SIZE_P = 18;
export const FONT_SIZE_H1 = 22;
export const FONT_SIZE_H2 = 20;
export const FONT_WEIGHT_H1 = '800';
