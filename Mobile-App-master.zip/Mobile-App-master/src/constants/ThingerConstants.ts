export const THINGER_SERVER = 'https://api.thinger.io';
