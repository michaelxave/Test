export default {
  api: {
    url: 'https://api.thinger.io',
  },
};
