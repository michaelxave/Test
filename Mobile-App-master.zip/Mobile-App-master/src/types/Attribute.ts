export type Attribute = string | number | boolean;
