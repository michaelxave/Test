/**
 * Mobile App for the Thinger.io Internet of Things Platform
 * https://thinger.io
 */

export type Style = { [key: string]: Object };
