export type ErrorResponse = {
  error: {
    message: string;
  };
};
